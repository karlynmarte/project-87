import React from "react"
import{createStackNavigator} from @react-navigation/createStackNavigator
import TabNavigator from "./Tabnavigator"
import PostScreen from "../screens/PostScreen"

const Stack = createStackNavigator
const StackNavigator = () => {
  return (
    <Stack.Navigator
    initialRouteName="home"
    screenOptions={{
      headerShown:false 
      >
    }}
    <Stack.Screen name = "Home" component{TabNavigator} />
    <Stack.Screen name= "PostScreen" component{PostScreen}/>
    </StackNavigator>
  )
}
export default StackNavigator